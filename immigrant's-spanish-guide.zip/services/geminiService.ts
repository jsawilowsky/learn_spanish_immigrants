
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { QuizQuestion, InterviewQuestion, Article } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const generateContentWithSchema = async <T,>(prompt: string, schema: any): Promise<T> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema,
            },
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as T;
    } catch (error) {
        console.error("Error fetching or parsing data from Gemini API:", error);
        throw new Error("Failed to generate content from AI. Please try again.");
    }
};

const bilingualTextSchema = {
    type: Type.OBJECT,
    properties: {
        spanish: { type: Type.STRING },
        english: { type: Type.STRING },
    },
    required: ["spanish", "english"],
};

export const getCivicsQuiz = async (countryName: string): Promise<QuizQuestion[]> => {
    const prompt = `You are an expert in Latin American civics and a Spanish language tutor.
    Generate 5 multiple-choice quiz questions about the civics of ${countryName}.
    For each question, its options, and the correct answer, provide both the Spanish text and an accurate English translation.
    The questions must be tailored to the specific dialect and common knowledge for someone seeking to immigrate to ${countryName}.
    Cover topics like independence day, government branches, number of states/provinces, current leader, and a key constitutional fact.

    Provide the response strictly in the specified JSON format. The 'options' array must contain exactly four unique items.`;

    const schema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                question: bilingualTextSchema,
                options: { type: Type.ARRAY, items: bilingualTextSchema },
                correctAnswer: bilingualTextSchema,
            },
            required: ["question", "options", "correctAnswer"],
        },
    };

    return generateContentWithSchema<QuizQuestion[]>(prompt, schema);
};

export const getInterviewQuestions = async (countryName: string): Promise<InterviewQuestion[]> => {
    const prompt = `You are an immigration consultant and Spanish language tutor.
    Generate 5 common interview questions for an immigration or residency interview in ${countryName}.
    For each question and its sample answer, provide both the Spanish text and an accurate English translation.
    The questions and answers should reflect the cultural and linguistic nuances of ${countryName}.
    Topics should include reasons for immigrating, personal background, and future plans.

    Provide the response strictly in the specified JSON format.`;
    
    const schema = {
        type: Type.ARRAY,
        items: {
            type: Type.OBJECT,
            properties: {
                question: bilingualTextSchema,
                sampleAnswer: bilingualTextSchema,
            },
            required: ["question", "sampleAnswer"],
        },
    };

    return generateContentWithSchema<InterviewQuestion[]>(prompt, schema);
};

export const getReadingArticle = async (countryName: string): Promise<Article> => {
    const prompt = `You are a journalist and Spanish language tutor specializing in content for new immigrants in ${countryName}.
    Write a short newspaper-style article (about 150-200 words) about a recent positive local event or a cultural topic relevant to someone new in ${countryName}. Use an intermediate vocabulary level.
    The article's title and its comprehension questions/answers must have both Spanish and English versions.
    The main content of the article must be an array of sentence objects, where each object contains the Spanish sentence and its English translation.
    The tone should be informative and welcoming.

    Provide the response strictly in the specified JSON format.`;

    const schema = {
        type: Type.OBJECT,
        properties: {
            title: bilingualTextSchema,
            content: {
                type: Type.ARRAY,
                items: bilingualTextSchema,
            },
            questions: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        question: bilingualTextSchema,
                        answer: bilingualTextSchema,
                    },
                    required: ["question", "answer"],
                },
            },
        },
        required: ["title", "content", "questions"],
    };

    return generateContentWithSchema<Article>(prompt, schema);
};

export const getSpeechAudio = async (text: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Kore' },
                    },
                },
            },
        });
        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (!base64Audio) {
            throw new Error("No audio data returned from API.");
        }
        return base64Audio;
    } catch (error) {
        console.error("Error fetching speech audio from Gemini API:", error);
        throw new Error("Failed to generate audio. Please try again.");
    }
};


// --- Audio Utilities ---

function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / 1; // 1 channel
  const buffer = ctx.createBuffer(1, frameCount, 24000); // 1 channel, 24000 sample rate

  const channelData = buffer.getChannelData(0);
  for (let i = 0; i < frameCount; i++) {
    channelData[i] = dataInt16[i] / 32768.0;
  }
  return buffer;
}


let audioContext: AudioContext | null = null;
const getAudioContext = (): AudioContext => {
  if (!audioContext || audioContext.state === 'closed') {
    audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  }
  return audioContext;
};

export const playAudio = async (base64Audio: string) => {
    try {
        const ctx = getAudioContext();
        if (ctx.state === 'suspended') {
            await ctx.resume();
        }
        const decodedBytes = decode(base64Audio);
        const audioBuffer = await decodeAudioData(decodedBytes, ctx);
        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(ctx.destination);
        source.start();
    } catch (error) {
        console.error("Error playing audio:", error);
    }
};
