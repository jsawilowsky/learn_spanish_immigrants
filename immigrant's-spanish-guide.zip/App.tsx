
import React, { useState, useMemo } from 'react';
import { Country, LearningModuleType } from './types';
import { COUNTRIES } from './constants';
import Header from './components/Header';
import CountrySelector from './components/CountrySelector';
import CivicsQuiz from './components/CivicsQuiz';
import InterviewPractice from './components/InterviewPractice';
import ReadingComprehension from './components/ReadingComprehension';
import { BookOpenIcon, MicrophoneIcon, NewspaperIcon } from './components/Icons';

const App: React.FC = () => {
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);
  const [currentModule, setCurrentModule] = useState<LearningModuleType>(LearningModuleType.Civics);

  const handleCountrySelect = (country: Country) => {
    setSelectedCountry(country);
    // Reset to the first module when a new country is selected
    setCurrentModule(LearningModuleType.Civics);
  };

  const handleReset = () => {
    setSelectedCountry(null);
  };
  
  const moduleTabs = [
    { name: LearningModuleType.Civics, icon: BookOpenIcon },
    { name: LearningModuleType.Interview, icon: MicrophoneIcon },
    { name: LearningModuleType.Reading, icon: NewspaperIcon },
  ];

  const CurrentModuleComponent = useMemo(() => {
    if (!selectedCountry) return null;

    switch (currentModule) {
      case LearningModuleType.Civics:
        return <CivicsQuiz key={selectedCountry.name} country={selectedCountry} />;
      case LearningModuleType.Interview:
        return <InterviewPractice key={selectedCountry.name} country={selectedCountry} />;
      case LearningModuleType.Reading:
        return <ReadingComprehension key={selectedCountry.name} country={selectedCountry} />;
      default:
        return null;
    }
  }, [currentModule, selectedCountry]);

  return (
    <div className="min-h-screen bg-slate-900 text-gray-100 flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <Header />
      <main className="w-full max-w-4xl mx-auto flex-grow">
        {!selectedCountry ? (
          <div className="text-center mt-16 animate-fade-in">
            <h2 className="text-3xl sm:text-4xl font-bold text-sky-400 mb-4">Welcome!</h2>
            <p className="text-lg text-slate-300 mb-8 max-w-2xl mx-auto">
              Start your journey by selecting a country. We'll tailor the Spanish lessons and civics content specifically for you.
            </p>
            <CountrySelector countries={COUNTRIES} onSelectCountry={handleCountrySelect} />
          </div>
        ) : (
          <div className="animate-fade-in">
            <div className="flex flex-col sm:flex-row justify-between items-center mb-6 bg-slate-800/50 p-4 rounded-xl">
              <h2 className="text-2xl font-bold">
                Learning for: <span className="text-sky-400">{selectedCountry.flag} {selectedCountry.name}</span>
              </h2>
              <button
                onClick={handleReset}
                className="mt-3 sm:mt-0 bg-slate-700 hover:bg-slate-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-300"
              >
                Change Country
              </button>
            </div>

            <div className="mb-6">
              <div className="flex space-x-2 sm:space-x-4 border-b border-slate-700">
                {moduleTabs.map((tab) => (
                  <button
                    key={tab.name}
                    onClick={() => setCurrentModule(tab.name)}
                    className={`flex items-center space-x-2 py-3 px-4 font-semibold text-sm sm:text-base transition-colors duration-300 ${
                      currentModule === tab.name
                        ? 'border-b-2 border-sky-400 text-sky-400'
                        : 'text-slate-400 hover:text-sky-300'
                    }`}
                  >
                    <tab.icon className="w-5 h-5" />
                    <span>{tab.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-slate-800 rounded-xl shadow-2xl p-4 sm:p-8">
              {CurrentModuleComponent}
            </div>
          </div>
        )}
      </main>
      <footer className="w-full max-w-4xl mx-auto text-center text-slate-500 py-6 mt-8">
        <p>&copy; {new Date().getFullYear()} Immigrant's Spanish Guide. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default App;
