
import { Country } from './types';

export const COUNTRIES: Country[] = [
  { name: 'Mexico', flag: '🇲🇽' },
  { name: 'Panama', flag: '🇵🇦' },
  { name: 'Paraguay', flag: '🇵🇾' },
  { name: 'Argentina', flag: '🇦🇷' },
  { name: 'Colombia', flag: '🇨🇴' },
  { name: 'Peru', flag: '🇵🇪' },
  { name: 'Chile', flag: '🇨🇱' },
  { name: 'Ecuador', flag: '🇪🇨' },
];
