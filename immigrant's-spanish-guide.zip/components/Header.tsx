
import React, { useState } from 'react';
import { getSpeechAudio, playAudio } from '../services/geminiService';
import { PlayIcon, AudioLoadingIcon } from './Icons';

const Header: React.FC = () => {
  return (
    <header className="w-full max-w-4xl mx-auto text-center mb-8 sm:mb-12">
      <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-emerald-500">
        Immigrant's Spanish Guide
      </h1>
      <p className="text-slate-400 mt-2 text-lg">
        Your personalized path to language and civics mastery.
      </p>
    </header>
  );
};

export default Header;


interface TextToSpeechButtonProps {
  text: string;
}

export const TextToSpeechButton: React.FC<TextToSpeechButtonProps> = ({ text }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handlePlay = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsLoading(true);
    setError(null);
    try {
      const audioData = await getSpeechAudio(text);
      await playAudio(audioData);
    } catch (err) {
      setError('Audio failed');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <button
      onClick={handlePlay}
      disabled={isLoading}
      className="inline-flex items-center justify-center w-7 h-7 rounded-full text-sky-300 hover:bg-sky-500/20 disabled:text-slate-500 disabled:cursor-not-allowed transition-colors"
      aria-label="Play audio"
    >
      {isLoading ? (
        <AudioLoadingIcon className="w-5 h-5" />
      ) : (
        <PlayIcon className="w-5 h-5" />
      )}
      {error && <span className="text-xs text-red-400 ml-1">!</span>}
    </button>
  );
};
